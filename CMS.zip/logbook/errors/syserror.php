<!doctype html>
<!--[if lt IE 9]><html class="ie"><![endif]-->
<!--[if gte IE 9]><!--><html><!--<![endif]-->
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <title>Error</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<!--
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8" />
-->
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" media="screen"/>

</head>
<body lang="en-GB">
    <div class="container">
	<div class="row">
	   <div class="col-md-offset-3 col-md-6">
	       <p class="well">There has been a System Error</p>
	   </div>
	</div>
    </div>
</body>
</html>
