<?
	if(@mysql_connect("localhost"))
	{
		echo "OK";
	}
	else
	{
		echo "NOK";
	}
?>
